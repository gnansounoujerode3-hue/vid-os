#!/usr/bin/env python3
"""Probe media with ffprobe and emit normalized JSON."""
import argparse, json, shutil, subprocess, sys
from pathlib import Path


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("media", type=Path)
    p.add_argument("--output", type=Path)
    a = p.parse_args()
    if not a.media.is_file():
        p.error(f"media does not exist: {a.media}")
    ffprobe = shutil.which("ffprobe")
    if not ffprobe:
        print("ffprobe is required", file=sys.stderr); return 2
    cmd = [ffprobe, "-v", "error", "-show_format", "-show_streams", "-of", "json", str(a.media)]
    result = subprocess.run(cmd, text=True, capture_output=True)
    if result.returncode:
        print(result.stderr.strip(), file=sys.stderr); return result.returncode
    raw = json.loads(result.stdout)
    streams = raw.get("streams", [])
    out = {
        "path": str(a.media.resolve()), "bytes": a.media.stat().st_size,
        "duration_seconds": float(raw.get("format", {}).get("duration", 0) or 0),
        "format": raw.get("format", {}).get("format_name"),
        "video": [], "audio": [], "subtitle": []
    }
    for s in streams:
        kind = s.get("codec_type")
        item = {k: s.get(k) for k in ("index", "codec_name", "profile", "width", "height", "pix_fmt", "r_frame_rate", "avg_frame_rate", "sample_rate", "channels", "channel_layout", "duration", "tags") if s.get(k) is not None}
        if kind in out: out[kind].append(item)
    text = json.dumps(out, indent=2, ensure_ascii=False) + "\n"
    if a.output:
        a.output.parent.mkdir(parents=True, exist_ok=True); a.output.write_text(text, encoding="utf-8")
    else: print(text, end="")
    return 0
if __name__ == "__main__": raise SystemExit(main())
