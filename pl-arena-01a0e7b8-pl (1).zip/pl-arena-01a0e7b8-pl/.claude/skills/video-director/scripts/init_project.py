#!/usr/bin/env python3
"""Initialize a reproducible video-director project without overwriting files."""
import argparse, re
from pathlib import Path

DIRS = ["sources", "capture", "assets", "transcripts", "edit", "compositions", "subtitles", "audio", "snapshots", "renders"]
BRIEF = """# Brief\n\n- Objective:\n- Audience:\n- Core message:\n- Inputs and source-of-truth order:\n- Deliverable / platform:\n- Duration / format / fps: 1080×1920, 30 fps (default; adapt as needed)\n- Art direction and reference fidelity:\n- Voice / captions / sound:\n- Brand must-haves and prohibitions:\n- Rights / privacy / external-service consent:\n- Budget: €0 unless approved otherwise\n- Checkpoints:\n- Acceptance criteria:\n- Workflow / engine:\n"""
STORY = "# Storyboard\n\n| # | Time | Narration / audio | Visual | Motion / transition | Assets |\n|---:|---|---|---|---|---|\n"

def main() -> int:
    p = argparse.ArgumentParser(); p.add_argument("name"); p.add_argument("--root", type=Path, default=Path("videos")); a = p.parse_args()
    slug = re.sub(r"[^a-z0-9]+", "-", a.name.lower()).strip("-")
    if not slug: p.error("name must contain letters or digits")
    root = a.root / slug; root.mkdir(parents=True, exist_ok=True)
    for d in DIRS: (root/d).mkdir(exist_ok=True)
    for path, content in [(root/"BRIEF.md", BRIEF), (root/"STORYBOARD.md", STORY), (root/"report.md", "# Production report\n")]:
        if not path.exists(): path.write_text(content, encoding="utf-8")
    print(root)
    return 0
if __name__ == "__main__": raise SystemExit(main())
