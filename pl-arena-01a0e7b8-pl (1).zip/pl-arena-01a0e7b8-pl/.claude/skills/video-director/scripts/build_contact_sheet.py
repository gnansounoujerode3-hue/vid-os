#!/usr/bin/env python3
"""Create an evenly sampled video contact sheet with FFmpeg."""
import argparse, json, math, shutil, subprocess, sys, tempfile
from pathlib import Path


def duration(path: Path) -> float:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)], text=True, capture_output=True, check=True)
    return float(json.loads(r.stdout)["format"]["duration"])


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("media", type=Path); p.add_argument("output", type=Path)
    p.add_argument("--frames", type=int, default=12); p.add_argument("--columns", type=int, default=4)
    p.add_argument("--width", type=int, default=360)
    a = p.parse_args()
    if not a.media.is_file(): p.error(f"media does not exist: {a.media}")
    if a.frames < 1 or a.columns < 1 or a.width < 64: p.error("invalid layout values")
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        print("ffmpeg and ffprobe are required", file=sys.stderr); return 2
    try: dur = duration(a.media)
    except Exception as e: print(f"cannot probe media: {e}", file=sys.stderr); return 3
    rows = math.ceil(a.frames / a.columns)
    interval = max(dur / (a.frames + 1), 0.001)
    vf = f"fps=1/{interval},scale={a.width}:-2:flags=lanczos,tile={a.columns}x{rows}:padding=8:margin=8"
    a.output.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-y", "-v", "error", "-i", str(a.media), "-vf", vf, "-frames:v", "1", str(a.output)]
    r = subprocess.run(cmd, text=True, capture_output=True)
    if r.returncode: print(r.stderr.strip(), file=sys.stderr); return r.returncode
    if not a.output.is_file() or a.output.stat().st_size == 0: print("contact sheet was not created", file=sys.stderr); return 4
    print(a.output)
    return 0
if __name__ == "__main__": raise SystemExit(main())
