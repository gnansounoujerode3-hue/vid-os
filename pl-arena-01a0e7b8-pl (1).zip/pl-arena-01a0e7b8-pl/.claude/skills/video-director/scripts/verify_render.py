#!/usr/bin/env python3
"""Apply blocking, machine-checkable render checks and emit a JSON report."""
import argparse, json, shutil, subprocess, sys
from pathlib import Path


def ratio(value: str) -> float:
    n, d = value.split("/"); return float(n) / float(d) if float(d) else 0


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("media", type=Path); p.add_argument("--output", type=Path)
    p.add_argument("--width", type=int); p.add_argument("--height", type=int); p.add_argument("--fps", type=float)
    p.add_argument("--min-duration", type=float, default=0.1); p.add_argument("--max-duration", type=float)
    p.add_argument("--require-audio", action="store_true"); p.add_argument("--require-video", action="store_true", default=True)
    a = p.parse_args(); checks = []
    def add(name, passed, detail): checks.append({"name": name, "passed": bool(passed), "detail": detail})
    add("file_exists", a.media.is_file(), str(a.media))
    if not a.media.is_file() or not shutil.which("ffprobe"):
        add("ffprobe_available", bool(shutil.which("ffprobe")), "ffprobe must be installed")
    else:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(a.media)], text=True, capture_output=True)
        add("ffprobe_readable", r.returncode == 0, r.stderr.strip() or "readable")
        if r.returncode == 0:
            data = json.loads(r.stdout); streams = data.get("streams", []); videos = [s for s in streams if s.get("codec_type") == "video"]; audios = [s for s in streams if s.get("codec_type") == "audio"]
            dur = float(data.get("format", {}).get("duration", 0) or 0)
            add("duration_min", dur >= a.min_duration, f"{dur:.3f}s >= {a.min_duration:.3f}s")
            if a.max_duration is not None: add("duration_max", dur <= a.max_duration, f"{dur:.3f}s <= {a.max_duration:.3f}s")
            if a.require_video: add("video_present", bool(videos), f"{len(videos)} video stream(s)")
            if a.require_audio: add("audio_present", bool(audios), f"{len(audios)} audio stream(s)")
            if videos:
                v = videos[0]
                if a.width: add("width", v.get("width") == a.width, f"{v.get('width')} == {a.width}")
                if a.height: add("height", v.get("height") == a.height, f"{v.get('height')} == {a.height}")
                if a.fps:
                    actual = ratio(v.get("avg_frame_rate", "0/1")); add("fps", abs(actual-a.fps) <= 0.02, f"{actual:.3f} ~= {a.fps:.3f}")
    report = {"media": str(a.media), "passed": all(c["passed"] for c in checks), "checks": checks, "manual_checks_required": ["contact-sheet visual inspection", "audio listening", "copy and factual review", "rights/provenance review"]}
    text = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if a.output: a.output.parent.mkdir(parents=True, exist_ok=True); a.output.write_text(text, encoding="utf-8")
    else: print(text, end="")
    return 0 if report["passed"] else 1
if __name__ == "__main__": raise SystemExit(main())
