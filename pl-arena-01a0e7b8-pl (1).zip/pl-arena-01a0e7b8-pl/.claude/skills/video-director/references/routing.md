# Routing

Choose by requested deliverable, then privacy, fidelity, cost, and available compute.

| Input / goal | Primary path | Supporting path |
|---|---|---|
| Existing spoken footage: trim, reorder, clean | FFmpeg + edit plan | local STT or consented AssemblyAI; HyperFrames for designed overlays |
| Plain captions on footage | FFmpeg/HyperFrames caption workflow | STT selected by privacy and accuracy |
| Ad, product launch, URL showcase | HyperFrames product workflow | capture, voice, FFmpeg QA |
| Topic, PDF, notes, tutorial | HyperFrames explainer/general workflow | source extraction, voice, captions |
| Short motion-first unit | HyperFrames motion workflow | Three.js for true 3D |
| Reference reproduction | shot/timing analysis, then HyperFrames or FFmpeg | image/audio comparison |
| Music-led edit | beat analysis + HyperFrames/FFmpeg | licensed audio provenance |
| Diagnostic/render-only request | existing project's own stack | FFprobe, snapshots, contact sheet |
| Long-form or unusual pipeline | FFmpeg-centric custom workflow | proxies and selective authored overlays |

## Selection questions

1. Is this a specific edit? Do only that edit; do not restart intake.
2. Does an existing project declare its engine? Keep it unless it cannot meet the request.
3. Is exact footage manipulation dominant? Prefer FFmpeg.
4. Is authored graphic motion dominant? Prefer HyperFrames.
5. Is true perspective/depth essential? Use Three.js/WebGL or actual 3D media, not flat substitutes.
6. Does transcription require external upload? Obtain consent or route local.
7. Would the route cost money? Stay local/free or ask first.

## Compute adaptation

Probe CPU count, RAM, GPU and encoders. Use proxies and bounded worker counts on constrained systems. Preview at reduced resolution only; restore final resolution and quality for delivery. Keep intermediate files outside Git unless they are required source assets.
