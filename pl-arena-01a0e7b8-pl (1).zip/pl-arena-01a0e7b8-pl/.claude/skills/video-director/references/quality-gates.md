# Quality gates

## Blocking technical checks

- output exists, is non-empty and FFprobe-readable;
- expected video and audio streams are present;
- duration, dimensions, ratio, fps and codec meet the brief;
- no decode error, missing asset, runtime error, accidental black/frozen section or truncated ending;
- audio is not clipped, absent, unintelligible or unexpectedly silent;
- subtitles parse, fit duration and remain synchronized.

## Visual review

Build a contact sheet across the complete timeline and inspect at full display size. Check hierarchy, typography, spelling, contrast, safe areas, faces, products, perspective, depth, continuity, transitions, logo treatment, final CTA and reference fidelity. Sample transition boundary frames, not only evenly spaced frames.

## Content and rights

Validate factual claims against sources. Confirm every external asset's provenance/license and every external upload's consent. Ensure generated content does not misrepresent the real product.

## Delivery threshold

All blocking checks pass and the overall creative result is judged high quality. A numerical score never overrides a blocking defect. Report commands and observed results; do not report “verified” without evidence.
