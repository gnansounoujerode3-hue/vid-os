# Source analysis

## Media inventory

For each file record path, media type, bytes, duration, dimensions, fps, codec, audio streams, sample rate, channels, language tags and rotation. Use `probe_media.py` or FFprobe; never infer from extension.

## Video and reference analysis

- Detect shots, scene boundaries, black frames, freezes, silences and loudness changes.
- Create a representative contact sheet spanning the entire timeline.
- Record structure as time ranges: subject, framing, camera, movement, depth, text, palette, transition, audio cue.
- Extract visible copy and verify spelling; do not invent unreadable text.
- For faithful reproduction, measure timing and geometry rather than describing only the mood.
- Distinguish real 3D, 2.5D layering, perspective transforms and flat graphics. Preserve the observed dimensional model.

## Spoken media

Generate or obtain word timing when cuts or karaoke captions need it. Identify filler, repetition, false starts, weak takes, long pauses and semantic highlights. Preserve natural breaths and meaning even when applying aggressive cleanup.

## Documents and URLs

Extract claims, hierarchy, branding, media and CTA. Cite the source used for factual claims. Capture real product UI where lawful and practical; do not create a misleading imitation.

## Privacy

Classify source material as public, internal, confidential, personal, or highly sensitive. External transcription/generation requires explicit consent. Remove temporary extracted data after delivery when it is no longer needed.
