# Audio and voice

Ask whether the project needs voiceover. French international is the language default only after voiceover is chosen. Register/select voice through the available speech workflow; never clone or imitate an identifiable person without explicit authorization.

## Transcription selection

- Use local STT for sensitive material, no upload consent, or offline operation.
- Use AssemblyAI when consent exists and its word timing/accuracy/features justify cloud processing; load the installed AssemblyAI skill for current API rules.
- Do not expose keys. Confirm free-tier availability before a cloud request under the €0 policy.

## Mix

Prioritize intelligibility. Clean noise conservatively, level dialogue, duck music under speech, use impacts and transitions sparingly, avoid clipping, and inspect the muxed final—not only stems. Preserve room tone over edits where silence sounds unnatural.

Record sources and licenses for music and effects. Prefer instrumental music under speech. Do not use copyrighted material without permission merely because it is accessible online.
