# Captions

Caption design follows platform, language, pace and accessibility. Produce a sidecar file when useful and embed/burn captions only as requested by the delivery context.

For fast vertical content, start with short chunks—often one to four words—and consider highlighting the current word. The source guide's two-word/blue-highlight rule is a style hypothesis, not a universal requirement. Increase chunk size for calm narration or reading comfort; follow brand colors and maintain contrast.

Requirements:
- derive timing from final edited audio;
- keep words exact unless explicitly editing disfluencies for readability;
- avoid orphaned articles/prepositions and awkward semantic breaks;
- remain inside platform safe areas and clear faces/product controls;
- use readable size, outline/background and sufficient contrast;
- verify first cue, final cue, overlaps, gaps, UTF-8 accents and frame-rate conversions.
