# Delivery platforms

Choose from current destination requirements when stated. Otherwise use these production defaults, then verify against the platform before publication.

| Use | Canvas | FPS | Notes |
|---|---:|---:|---|
| Vertical social | 1080×1920 | 30 | default; keep critical text in central safe area |
| Square social | 1080×1080 | 30 | recompose, do not merely crop important subjects |
| Landscape web | 1920×1080 | 30 | 24/25/60 only with a reason |
| Source-faithful edit | match source/master | match or deliberate conversion | avoid needless cadence conversion |

Preferred interchange is a high-quality master plus H.264/AAC MP4 delivery. Use `yuv420p` for broad compatibility unless HDR/alpha requirements dictate another format. State codec, dimensions, fps, duration and audio configuration in the report.
