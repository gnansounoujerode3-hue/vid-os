# Project layout

Use the lightest structure that preserves reproducibility.

Small edit: `BRIEF.md`, `sources/`, `edit/`, `renders/`, `report.md`.

Major production:

```text
videos/<slug>/
├── BRIEF.md
├── SCRIPT.md
├── STORYBOARD.md
├── sources/        # immutable supplied media
├── capture/        # URL/reference capture and extraction
├── assets/         # approved production assets + provenance
├── transcripts/    # transcript and word timings
├── edit/           # EDL/manifests/proxies metadata
├── compositions/   # authored source
├── subtitles/      # SRT/VTT/ASS
├── audio/          # voice, music, SFX, stems
├── snapshots/      # QA frames/contact sheet
├── renders/        # masters and delivery encodes
└── report.md
```

Do not commit disposable proxies, caches or duplicate renders unless the repository intentionally versions them. Never modify originals in `sources/`.
