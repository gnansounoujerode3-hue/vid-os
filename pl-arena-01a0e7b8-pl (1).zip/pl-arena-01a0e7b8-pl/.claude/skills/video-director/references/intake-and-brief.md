# Intake and brief

## Infer before asking

Inspect supplied media, URL, brand files, existing project documents and platform clues. Ask one compact round only for high-impact unknowns. Typical decisions: objective, audience, destination, duration, call to action, reference fidelity, voiceover, publication status, and sensitive-data constraints.

Voiceover is a per-project decision. When requested, ask or infer with confirmation: language, accent, gender presentation, tone, pace and pronunciation.

## BRIEF.md minimum

```markdown
# Brief
- Objective:
- Audience:
- Core message:
- Inputs and source-of-truth order:
- Deliverable / platform:
- Duration / format / fps:
- Art direction and reference fidelity:
- Voice / captions / sound:
- Brand must-haves and prohibitions:
- Rights / privacy / external-service consent:
- Budget: €0 unless approved otherwise
- Checkpoints:
- Acceptance criteria:
- Workflow / engine:
```

Record assumptions explicitly. If the user says “use your judgment,” choose and document rather than reopening questions. For an existing project, amend only decisions affected by the request.
