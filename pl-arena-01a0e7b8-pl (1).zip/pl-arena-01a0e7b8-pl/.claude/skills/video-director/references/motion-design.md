# Motion design

Motion explains hierarchy and causality. Every entrance, camera move and transition must support a narrative beat.

## Short-video starting hypotheses

The source guide recommends these useful test defaults for mobile shorts:

- crisp transitions around 0.4 s, with motion blur only during travel and a stable end state;
- scenes no longer than about 6 s when the sentence can be communicated sooner;
- spoken figures made visually prominent for about 0.5 s, without fabricating precision;
- avoid reusing the same hero visual twice;
- reserve complex 3D for moments where depth earns attention, then return to simpler information graphics.

These are not universal laws. Match a supplied reference and adjust for calm, premium, cinematic, educational or accessibility needs.

## Depth and 3D

When the concept or reference is dimensional, preserve perspective, occlusion, materials, shadows, lighting and camera parallax. Prefer true Three.js/WebGL/GLB rendering when flat CSS cannot preserve the effect. Do not replace a dimensional brain, product, globe or device with a flat pictogram.

## Reusable components

Catalog accepted components rather than accumulating anonymous files. Useful categories: alpha graphics, editable SVG icons, HTML/SVG infographics, true 3D objects, deterministic backgrounds, number hits, entrances, layouts, music prompts, B-roll and sound effects. Validate at delivery size before cataloging.

## Determinism

Bind animation state to timeline time. Seed randomness. Ensure a frame rendered out of order is identical to the same frame rendered sequentially. Test beginning, transition, mid-scene and final frames.
