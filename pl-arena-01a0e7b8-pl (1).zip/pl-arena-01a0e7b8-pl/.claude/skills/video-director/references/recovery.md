# Recovery

1. Capture the exact failing command, exit status and relevant logs.
2. Classify: input corruption, dependency/version, credentials/quota, network/provider, compute, composition/runtime, encoding or QA failure.
3. Retry only transient failures and cap retries.
4. Use a safe fallback that preserves the brief: cloud STT → consented alternative or local STT; GPU → CPU; full preview → proxy preview; codec → compatible equivalent.
5. Re-run all affected quality gates after fallback.
6. Stop and ask when fallback changes quality materially, costs money, sends data externally, changes rights, or contradicts an approved creative decision.

Never hide fallback use. State what failed, what replaced it, quality implications and how it was verified.
