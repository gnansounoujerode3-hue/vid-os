# Editing

Create an edit decision plan before destructive processing. Keep source originals immutable.

## Spoken footage baseline

For short social and promotional work, aggressively remove dead air, repeated ideas, hesitation, errors and weak takes. Retain enough breathing room to avoid robotic cadence and jump-cut fatigue. Let interviews, testimony and sensitive statements remain natural where authenticity matters.

Use J/L cuts, B-roll, reframing or designed overlays to hide necessary discontinuities. Never disguise a semantic alteration. Keep captions aligned after every timing change.

## B-roll order

1. Supplied authorized media.
2. Existing project library with known provenance.
3. Free or licensed sourcing with recorded URL/license.
4. Generated media, clearly recorded as generated.

Reject irrelevant “filler” B-roll. Each shot must clarify, prove, pace or emotionally support the spoken idea.

## Reference fidelity

Match macro structure first, then scene duration, composition, depth, movement, easing, typography, grade and sound cues. Document intentional deviations. Never trade real depth for a flat icon merely because it is faster.

## Reproducibility

Pin dependencies; save exact commands, cut points, filters and render settings. Prefer nondestructive manifests or source compositions. Use deterministic seeds where generation permits.
