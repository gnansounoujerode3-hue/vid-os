# Iterative improvement

Follow the source guide's loop:

1. Keep the input brief fixed and render a concrete baseline.
2. Review observable differences, not vague impressions.
3. Convert recurring feedback into a rule containing action, context and reason.
4. Separate universal rules, project rules and optional style recipes.
5. Replace the superseded rule in its owning section; do not append a dated corrections pile.
6. Re-run the same brief and compare before/after.
7. Catalog validated components with searchable metadata.
8. Repeat until output is stable, then test a different real project to avoid overfitting.

Examples of useful feedback:
- “On fast vertical speech, keep caption chunks to at most two words so they can be read immediately on mobile.”
- “Use a 0.4 s transition only for energetic shorts; keep the element stationary after arrival to restore legibility.”

The user controls persistent preference changes. Propose them; never silently rewrite the creative profile.
