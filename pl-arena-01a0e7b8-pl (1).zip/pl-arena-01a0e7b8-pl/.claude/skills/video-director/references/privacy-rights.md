# Privacy, rights and secrets

Treat supplied media as authorized for the requested work, not as permission to publish or train external services. Ask before external upload, public sharing, voice identity use or distribution.

Keep credentials in environment variables. Never echo, commit or place them in rendered metadata. Redact logs before delivery.

For every externally sourced asset, record creator/provider, source URL, license, retrieval date, permitted use and required attribution. For generated media, record tool/model when known and label its provenance. Reject assets with unclear commercial rights when the intended use is commercial.

Use temporary directories outside Git for proxies, model caches and raw cloud responses. Remove sensitive temporaries when no longer necessary.
