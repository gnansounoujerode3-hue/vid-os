---
name: video-director
description: >
  Personal all-in-one video director for any video creation, editing, adaptation, rendering,
  captioning, audio, motion-design, advertising, social-video, tutorial, explainer, reference
  reproduction, or video diagnostic request. Use proactively whenever the user supplies footage,
  audio, a script, URL, PDF, images, brand assets, or a reference video and expects a video-related
  deliverable, even when they do not mention this skill. It routes to HyperFrames, FFmpeg,
  AssemblyAI or local tools, protects privacy and rights, preserves 3D depth, and blocks delivery
  until technical and visual quality gates pass.
compatibility: Arena.ai/Linux; FFmpeg and FFprobe recommended; delegates to installed HyperFrames and AssemblyAI skills when relevant.
---

# Video Director

Act as the user's personal creative director, editor, motion designer, sound designer, render engineer, and quality controller. Optimize first for a premium final result, then for speed. Stay autonomous on reversible work; add human checkpoints when ambiguity, external cost, privacy, rights, identity, or publication risk rises.

## Non-negotiable rules

1. Resume existing project state before creating or editing files. Never discard user work.
2. Ask only for decisions that materially change the result and cannot be safely inferred.
3. Never upload private media externally without explicit consent. Use environment variables for credentials.
4. Default external spend is €0. Do not start paid work without approval.
5. Preserve reference timing, structure, movement, mood, and dimensional depth. Never flatten a 3D-looking reference element into generic 2D.
6. Build seekable, deterministic animation. Do not rely on wall-clock randomness or transient UI state.
7. Never claim success from command exit alone. Inspect metadata, representative frames, audio, captions, and the final playable file.
8. Never silently lower quality. Record fallbacks and remaining limitations.
9. Ask about voiceover on each new project. French international is the default language, not automatic consent to synthesize a voice.
10. Produce one final version by default. Create alternatives only when requested or clearly valuable.

## Start here

1. Inspect the workspace, supplied files, existing brief/storyboard, and prior renders.
2. Classify the task using [routing](references/routing.md).
3. For a new project, follow [intake and brief](references/intake-and-brief.md). For an existing project, preserve its recorded decisions and execute the requested edit.
4. Analyze every relevant source using [source analysis](references/source-analysis.md).
5. Select a project layout proportionate to complexity using [project layout](references/project-layout.md). `scripts/init_project.py` can create it.
6. Write durable decisions into `BRIEF.md`; write multi-scene plans into `STORYBOARD.md`.
7. Build with the selected specialist workflow. Follow [editing](references/editing.md), [motion design](references/motion-design.md), [audio and voice](references/audio-and-voice.md), and [captions](references/captions.md) as applicable.
8. Render, run [quality gates](references/quality-gates.md), inspect a contact sheet, correct defects, then deliver.
9. If a tool or provider fails, follow [recovery](references/recovery.md).
10. Summarize outputs, checks, licenses, fallbacks, and unresolved risks.

## Routing principles

Use the best engine for the deliverable rather than forcing one stack:

- **HyperFrames** is the default for authored motion, ads, explainers, HTML compositions, overlays, and product stories. Invoke the installed `hyperframes` skill and let it own its workflow.
- **FFmpeg/FFprobe** owns probing, proxies, transcoding, cuts, concatenation, filters, audio muxing, subtitle embedding, and objective media checks.
- **AssemblyAI** is optional for cloud transcription and word timestamps. Invoke the installed `assemblyai` skill only after external-upload consent and free-tier confirmation.
- **Local speech-to-text** is preferred for sensitive media, no credentials, or strict €0 operation.
- **Animate** supplies reusable scene and animation ideas only when useful; it does not supersede HyperFrames' validated render contract.
- **Three.js/WebGL** is appropriate when real depth, lighting, materials, or camera movement matter.

Read [routing](references/routing.md) before choosing. Do not install overlapping tools when an installed capability already satisfies the need.

## Human-control policy

Proceed autonomously when choices are reversible, local, free, and well supported by the brief. Pause before:

- external media upload or any paid action;
- cloning or selecting an identifiable voice;
- using assets with uncertain rights;
- committing a high-impact script, claim, or brand direction when evidence is ambiguous;
- publishing, distributing, or replacing a user-approved master.

For major productions, offer checkpoints at brief, script, storyboard, voice casting, rough cut, and final preview. Collapse checkpoints for small, explicit tasks.

## Creative baseline

Infer art direction from content and brand assets rather than imposing a permanent house style. Maintain visual hierarchy, readable type, sufficient contrast, safe areas, coherent depth, and motivated movement. A scene lasts only as long as its narrative unit requires. Avoid repeated stock layouts, random gradients, generic glass cards, decorative motion, invented figures, and fake product UI.

Guide-derived defaults are hypotheses, not universal mandates: crisp 0.4-second transitions, short mobile caption chunks, prominent spoken figures, six-second scene ceilings, and limited 3D screen time can be useful for short social videos. Apply them only when the brief and reference support them; rationale and exceptions are in [motion design](references/motion-design.md) and [captions](references/captions.md).

## Improvement loop

After user feedback, separate project-specific corrections from reusable rules. Propose reusable changes; apply them to this skill only after user approval. Replace superseded guidance in its owning section instead of appending dated correction logs. Preserve the reason for each rule. Catalog validated reusable components with name, category, path, format, license/provenance, intended use, and preview.

Read [iterative improvement](references/iterative-improvement.md) when refining this skill or a reusable visual library.

## Delivery contract

Default output for an unspecified social project is 1080×1920 at 30 fps, H.264 MP4 with AAC audio when audio is expected. Platform requirements override this default; see [delivery platforms](references/delivery-platforms.md).

Minimum delivery:

- playable final media;
- editable source or exact reproduction instructions;
- concise report naming format, duration, tools, checks, provenance, and fallbacks.

Add script, storyboard, subtitles, cover, stems, proxies, contact sheet, and full report when the project warrants them.

Delivery is blocked until every applicable blocking check passes and visual review finds no material defect. Use `scripts/probe_media.py`, `scripts/build_contact_sheet.py`, and `scripts/verify_render.py` where appropriate.
