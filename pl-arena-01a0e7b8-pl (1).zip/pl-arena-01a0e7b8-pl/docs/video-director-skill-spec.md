# Spécification du skill `video-director`

Statut : spécification initiale validable, à enrichir après analyse du PDF `guide_animate_agence_agentique.pdf`.

## 1. Vision

`video-director` est un studio vidéo agentique personnel capable de prendre en charge toute tâche vidéo concrète : création depuis un brief, une URL ou un document, montage de rushes, adaptation fidèle d’une référence, motion design, publicité, contenu social, vidéo éducative, voix off, sous-titres, mixage, rendu et contrôle qualité.

La priorité absolue est la **qualité visuelle maximale**. Le skill reste autonome par défaut, mais augmente les validations humaines selon l’ambiguïté, le risque, le coût et la sensibilité du projet.

## 2. Utilisateur et environnement

- Utilisateur principal : usage personnel.
- Environnement prioritaire : Arena.ai sous Linux.
- Détection automatique des ressources disponibles : CPU, mémoire, GPU, navigateur, FFmpeg et encodeurs.
- Réglage recommandé par défaut : 1080 × 1920, 30 fps.
- Les paramètres finaux dérivent néanmoins de la plateforme et du brief.
- Coût externe par défaut : 0 € ; outils locaux et quotas gratuits uniquement.
- Installation automatique permise pour les outils open source reconnus, sûrs et épinglés.

## 3. Déclenchement

Déclencher automatiquement `video-director` pour toute demande de :

- création ou génération vidéo ;
- montage, découpe, assemblage ou nettoyage de rushes ;
- publicité, démonstration produit, vidéo sociale ou explicative ;
- reproduction ou adaptation d’une vidéo de référence ;
- motion design, animation, transitions ou habillage ;
- transcription, sous-titres, voix off, musique ou mixage ;
- rendu, diagnostic, vérification, déclinaison ou publication vidéo.

Le skill peut être invoqué explicitement avec `/video-director`.

## 4. Sources acceptées

Accepter et combiner :

- brief texte et script ;
- URL de site ou d’application ;
- PDF et autres documents ;
- images, logos, chartes et polices ;
- fichiers audio, voix et musiques ;
- rushes vidéo, captures d’écran et animations ;
- vidéo de référence ;
- dossiers contenant plusieurs médias.

L’analyse est approfondie : métadonnées, transcription, intervenants, scènes, plans, rythme, silences, hésitations, moments forts, couleurs, typographie, textes visibles, visages, mouvements, musique, effets et structure narrative.

## 5. Architecture hybride

Le skill principal agit comme routeur et orchestrateur. Il s’appuie sur les skills existants et sur des références spécialisées.

### Moteurs

- **HyperFrames** : motion design, publicités, vidéos explicatives, animations, compositing HTML/CSS/GSAP et rendu déterministe.
- **FFmpeg/FFprobe** : analyse, proxies, découpe, assemblage, audio, sous-titres, encodage et vérification.
- **AssemblyAI** : transcription, diarisation, sous-titres et intelligence audio lorsque ce choix est adapté.
- **Whisper/local** : solution locale ou de secours lorsque la confidentialité, le coût ou l’absence de clé l’exige.
- **Animate** : patterns de scènes et idées d’animation, sans remplacer le moteur de rendu validé.
- **Remotion** : option future ou ciblée lorsque React/TypeScript apporte un avantage clair.

### Routage proposé

1. Rushes ou interview → analyse, transcription, plan de coupe, montage FFmpeg, habillage HyperFrames.
2. Brief, URL, PDF ou sujet → script, storyboard, assets, production HyperFrames.
3. Vidéo de référence → analyse image/son/timing puis reproduction fidèle.
4. Motion graphic court → HyperFrames ou pile d’animation la plus légère.
5. Projet multi-plateforme → master puis adaptations seulement si demandées ou réellement utiles.

## 6. Workflow canonique

1. **Reprendre l’état du projet** et ne jamais écraser les modifications existantes.
2. **Analyser les entrées** et classifier le projet.
3. **Recueillir uniquement les décisions manquantes** : destination, durée, fidélité, voix, contraintes et droits.
4. **Établir le brief durable** avec message, public, format, durée, style et livrables.
5. **Transcrire et comprendre** les médias lorsque nécessaire.
6. **Construire le script et le plan de montage**.
7. **Créer un storyboard** pour toute production comportant plusieurs scènes.
8. **Choisir le moteur** et générer proxies, assets et compositions.
9. **Monter l’image** : nettoyage agressif des rushes parlés par défaut, adapté au contexte.
10. **Créer la voix off** après confirmation de la langue, du genre, de l’accent et du ton.
11. **Concevoir le son** : musique, impacts, transitions, ambiances, ducking et mixage.
12. **Générer des sous-titres adaptatifs** selon plateforme, langue et densité.
13. **Vérifier**, corriger et rendre.
14. **Livrer** avec résumé ou rapport complet selon l’importance du projet.
15. **Proposer d’enregistrer les corrections récurrentes**, sans modifier silencieusement les préférences.

## 7. Création et montage

- Style de montage adaptatif à la plateforme, au public et au message.
- Nettoyage agressif des hésitations, répétitions, erreurs et silences pour les contenus courts et publicitaires.
- Préserver un rythme naturel lorsque le contexte l’exige.
- B-roll hybride : médias fournis d’abord, puis recherche ou génération avec provenance.
- Pour une référence, viser une reproduction très fidèle : timing, structure, profondeur, mouvement, ambiance et traitement sonore.
- La durée est recommandée selon la plateforme, expliquée puis verrouillée.
- Produire une seule version finale par défaut ; ne créer des variantes que sur demande ou si leur valeur est démontrée.

## 8. Direction artistique

La direction est inférée à partir du contenu, du public, de la marque et de la plateforme. Aucune préférence visuelle personnelle n’est mémorisée par défaut : la direction est redéfinie à chaque projet.

Règles non négociables :

- qualité premium et hiérarchie visuelle claire ;
- profondeur, ombres, perspective et détails cohérents ;
- ne jamais aplatir un élément 3D présent dans une référence ;
- fidélité aux actifs et à la charte fournis ;
- texte lisible, contrastes suffisants et zones sûres ;
- pas d’interface générique lorsque le produit réel peut être montré ;
- mouvements motivés par le récit, sans animation décorative gratuite ;
- sorties déterministes et reproductibles.

## 9. Audio et langue

- Langue principale : français international.
- Demander à chaque projet les choix de voix off : présence, genre, accent et ton.
- AssemblyAI, transcription locale ou autre fournisseur sont sélectionnés selon précision, confidentialité et coût.
- Design sonore complet disponible : voix, musique, ambiances, impacts, transitions, ducking et normalisation.
- Sous-titres adaptatifs pour toute vidéo parlée lorsque la plateforme ou l’usage le justifie.
- La voix reste intelligible et prioritaire dans le mix.

## 10. Confidentialité, droits et secrets

- Aucun média envoyé à un service externe sans accord explicite.
- Détecter les données sensibles ; préférer local, anonymisation ou demande de confirmation.
- Clés API uniquement via variables d’environnement ; jamais dans le chat, les fichiers versionnés ou le dépôt Git.
- Considérer les médias fournis par l’utilisateur comme autorisés.
- Vérifier la provenance et la licence des médias recherchés ou générés.
- Ne jamais publier sans accord humain.
- Les décisions humaines augmentent avec le risque : identité vocale, données sensibles, droits incertains, dépense et publication.

## 11. Livrables et structure

Livrables adaptatifs :

- minimum : MP4 final et résumé de vérification ;
- selon le projet : projet modifiable, brief, script, storyboard, sous-titres, miniature, EDL, stems audio, planche contact et rapport qualité.

Structure adaptative proposée :

```text
videos/<projet>/
├── BRIEF.md
├── sources/
├── capture/
├── assets/
├── transcripts/
├── SCRIPT.md
├── STORYBOARD.md
├── edit/
├── compositions/
├── subtitles/
├── audio/
├── snapshots/
├── renders/
└── report.md
```

## 12. Qualité et reprise sur erreur

Contrôles adaptatifs avec socle obligatoire :

- fichier présent, lisible et non vide ;
- codec, résolution, fps, durée et ratio conformes ;
- piste audio attendue réellement présente ;
- absence d’écran noir, scintillement, média manquant et erreur runtime ;
- débordements, contraste, zones sûres et texte lisible ;
- orthographe, synchronisation voix/image/sous-titres et cohérence narrative ;
- fidélité renforcée lorsqu’une référence existe ;
- niveau sonore, absence de clipping et continuité aux coupes ;
- vérification par tests automatiques et inspection d’une planche contact.

La livraison exige à la fois :

1. le passage de tous les contrôles bloquants ;
2. un score global de qualité élevé.

En cas d’échec : diagnostic, nouvelle tentative limitée, solution de secours sûre, puis escalade à l’utilisateur. Ne jamais réduire silencieusement la qualité ni prétendre qu’un rendu a réussi.

## 13. Checkpoints

Mode hybride : autonome par défaut, checkpoints adaptatifs.

Checkpoints possibles : brief, script, storyboard, casting vocal, premier montage, mixage, prévisualisation finale et publication. Les petits projets bien définis peuvent réduire ces pauses ; les projets coûteux, ambigus, sensibles ou publics les renforcent.

## 14. Documentation cible

Documentation exhaustive avec divulgation progressive :

```text
.claude/skills/video-director/
├── SKILL.md
├── references/
│   ├── routing.md
│   ├── intake-and-brief.md
│   ├── source-analysis.md
│   ├── editing.md
│   ├── reference-reproduction.md
│   ├── motion-design.md
│   ├── audio-and-voice.md
│   ├── captions.md
│   ├── delivery-platforms.md
│   ├── privacy-rights.md
│   ├── quality-gates.md
│   ├── recovery.md
│   └── project-layout.md
├── scripts/
│   ├── probe_media.py
│   ├── build_contact_sheet.py
│   ├── verify_render.py
│   └── init_project.py
├── assets/
│   └── templates/
└── evals/
    └── evals.json
```

Le `SKILL.md` reste compact et sert de routeur. Les références spécialisées sont chargées uniquement lorsqu’elles sont pertinentes.

## 15. Batterie d’évaluation prévue

1. Publicité verticale depuis une URL.
2. Montage court depuis plusieurs rushes parlés.
3. Reproduction française d’une vidéo de référence.
4. Vidéo explicative depuis un PDF.
5. Sous-titres multilingues et synchronisés.
6. Projet sans clé API ni accès cloud.
7. Projet contenant des données sensibles.
8. Déclinaisons de format et vérification des zones sûres.
9. Échec d’un fournisseur avec fallback local.
10. Vérification d’un rendu contenant volontairement un défaut.

Comparer les sorties avec et sans skill sur des critères objectifs et visuels : conformité, qualité, erreurs détectées, durée, coût, traçabilité et capacité à livrer un média valide.

## 16. Intégration du guide PDF

Le guide public `guide_animate_agence_agentique.pdf` a été lu depuis le dossier Google Drive fourni. Son analyse et sa table de traçabilité sont conservées dans `docs/source/guide-animate-analysis.md`.

Les principes retenus sont : livrer rapidement une première version concrète, comparer les itérations sur un brief stable, convertir les observations en règles réutilisables accompagnées de leur raison, intégrer les corrections dans leur section d’origine, construire progressivement une bibliothèque cataloguée, et itérer jusqu’à un résultat stable.

Les valeurs proposées par le guide — transition de 0,4 seconde, sous-titres de deux mots, chiffre mis en avant, scène de six secondes au maximum et temps limité pour certains objets 3D — deviennent des hypothèses contextuelles pour les vidéos sociales rapides. Elles ne remplacent pas les exigences déjà validées de rythme adaptatif, de fidélité à la référence et de préservation de la profondeur 3D.
