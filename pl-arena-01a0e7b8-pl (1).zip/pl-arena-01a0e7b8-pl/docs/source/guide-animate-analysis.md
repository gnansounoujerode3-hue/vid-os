# Analyse de `guide_animate_agence_agentique.pdf`

Source publique : https://drive.google.com/file/d/19xFtF3AkB-ipoR4gv19wfy1MzrDzvulK/view

Le PDF (9 pages, « Construis ton propre /ANIMATE ») a été lu depuis le dossier Google Drive communiqué par l’utilisateur. Le binaire n’est pas recopié dans Git ; ce document conserve les conclusions utiles et la traçabilité.

## Principes structurants

1. Créer d’abord une version fonctionnelle et concrète.
2. Tester sur un brief court et stable, puis comparer les versions sur la même entrée.
3. Transformer les observations en règles générales indiquant quoi faire, quand et pourquoi.
4. Fournir des références visuelles.
5. Construire progressivement une bibliothèque de composants validés et catalogués.
6. Intégrer chaque nouvelle règle dans sa section d’origine plutôt que d’empiler des journaux de corrections.
7. Garder le skill concis et remplacer les règles obsolètes.
8. Utiliser HyperFrames pour la composition vidéo et AssemblyAI pour transcription/timing lorsqu’ils conviennent.
9. Prévisualiser, exporter puis vérifier que le fichier final est lisible.
10. Itérer jusqu’à obtenir un résultat stable et prévisible.

## Règles proposées par le guide

Le guide donne comme exemples : transitions de 0,4 s ; sous-titres de deux mots avec mot courant bleu ; chiffres prononcés affichés en grand ; scène limitée à six secondes ; non-répétition d’un même visuel ; objet 3D limité dans le temps. `video-director` les traite comme des hypothèses adaptées aux vidéos sociales rapides, et non comme des règles universelles, car l’entretien utilisateur exige un rythme, des sous-titres et une direction adaptatifs ainsi qu’une fidélité forte aux références.

## Bibliothèque recommandée

Graphiques PNG alpha, icônes SVG, infographies HTML/SVG, objets Three.js/GLB, arrière-plans déterministes, chiffres clés, animations d’entrée, mises en page, musique, B-roll et effets sonores. Chaque élément retenu doit être catalogué avec chemin, catégorie et contexte d’usage ; `video-director` ajoute licence et provenance.

## Écarts volontaires de `video-director`

- Périmètre plus large que les seules vidéos courtes : rushes, publicités, tutoriels, diagnostics et adaptations.
- Sélection de moteur automatique au lieu d’imposer HyperFrames partout.
- AssemblyAI conditionnel à la confidentialité, au consentement, au coût et à la précision.
- Contrôles de droits, secrets, coût et publication absents ou peu détaillés dans le guide.
- Contrôles techniques et inspection par planche contact obligatoires.
- Préservation explicite de la profondeur 3D et fidélité de référence.
- Validation humaine proportionnelle au risque.

## Table de traçabilité

| Guide | Intégration |
|---|---|
| HyperFrames + AssemblyAI | `SKILL.md` routage ; `routing.md`; `audio-and-voice.md` |
| Prompt → scènes → visuels/sous-titres → preview → export → vérification | workflow principal du `SKILL.md` |
| Même brief pour comparer | `iterative-improvement.md` |
| Retours transformés en règles | `iterative-improvement.md` |
| Règle avec raison, intégrée à sa section | `iterative-improvement.md` |
| Bibliothèque cataloguée | `motion-design.md` |
| Transitions 0,4 s et scènes ≤6 s | `motion-design.md`, sous forme de défaut contextuel |
| Sous-titres courts synchronisés | `captions.md`, adaptatif |
| Chiffres visibles sans précision inventée | `motion-design.md` et exigences de véracité |
| Vraie 3D via Three.js | `motion-design.md` |
| Rendu lisible + source + couverture/note | contrat de livraison et `quality-gates.md` |
